# Iluilu Chatbot — Full project

Files included:
- `public/index.html` — Frontend (single-file SPA)
- `server.js` — Node/Express backend proxy to OpenAI
- `package.json` — Node dependencies
- `manifest.json` — PWA manifest

## Quick local run
1. Copy project to your machine.
2. Create `.env` with:
   OPENAI_API_KEY=your_api_key_here
3. Install:
   npm install
4. Start:
   npm start
5. Open http://localhost:3000

## Deploying
- **Backend + Frontend together**: Use Render, Heroku, Railway, or Vercel (Serverless functions).
- **Frontend only**: Deploy `public/index.html` to Netlify or GitHub Pages and point API calls to your backend.

## Android APK (PWA / TWA)
- Use PWABuilder, or Bubblewrap (Google's TWA) to wrap the PWA into an Android APK.
- Tools:
  - https://www.pwabuilder.com
  - https://github.com/GoogleChromeLabs/bubblewrap

## OpenAI notes
This project uses the official OpenAI Node client. See OpenAI API docs for the latest examples and model names.

Official docs: https://platform.openai.com/docs/api-reference/chat
